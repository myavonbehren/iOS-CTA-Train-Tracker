//
//  TrainArrivalService.swift
//  mvonbehr-hw2
//
//  Created by Mya Von Behren on 5/5/25.
//

import Foundation

class TrainArrivalService {
    let apiKey = "291d33ffcb8f401c8c41d051e6d873da"
    let baseURL = "https://lapi.transitchicago.com/api/1.0/ttarrivals.aspx"
    
    enum SerializationError:Error {
        case missing(String)
        case invalid(String,Any)
    }
    
    
    func fetchTrainArrivals(for mapID: String, completion: @escaping ([CTATrain]) -> Void) {
        let formattedURL = "\(baseURL)?key=\(apiKey)&mapid=\(mapID)&outputType=JSON"
                
        guard let feedURL = URL(string: formattedURL) else { return }
        
        let request = URLRequest(url: feedURL)
        let session = URLSession.shared
        
        session.dataTask(with: request) { data, response, error in
            guard error == nil else {
                print(error!.localizedDescription)
                return
            }
                        
            guard let data = data else {
                print("No data")
                return
            }
            
            do {
                let json = try JSONDecoder().decode(CTAResponse.self, from: data)
                let arrivals = json.ctatt.eta
                
                guard !arrivals.isEmpty else {
                    debugPrint("No arrivals")
                    return
                }
                
                for arrival in arrivals {
                    debugPrint(arrival)
                }
                
                DispatchQueue.main.async {
                    completion(arrivals)
                }
            } catch SerializationError.missing(let msg){
                print("Missing \(msg)")
            } catch SerializationError.invalid(let msg, let data){
                print("Invalid \(msg): \(data)")
            } catch let error as NSError {
                print("ERRRROORRR")
                print(error.localizedDescription)
                completion([])
            }
            
        }.resume()
    }
        
    
    
}
