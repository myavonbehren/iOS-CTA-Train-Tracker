//
//  mvonbehr_hw2Tests.swift
//  mvonbehr-hw2Tests
//
//  Created by Mya Von Behren on 5/4/25.
//

import Testing
@testable import mvonbehr_hw2

struct mvonbehr_hw2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
